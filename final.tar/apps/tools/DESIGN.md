# gwonmac interface system

This file defines the interface rules for gwonmac surfaces. Settings, Tools,
dialogs, lists, and skill bars use one component system.

## Visual styles

The system has two built-in styles and one saved custom palette:

- **Guild Wars** is the default. It uses ivory metal, parchment text,
  blue-black primary controls, graphite secondary controls, and gilt accents.
- **Modern** uses flat warm-black layers, quiet one-pixel borders, muted gilt
  accents, and limited shadow.
- **Custom** derives the complete system from a material style and semantic
  window, title bar, raised surface, recess, selection, accent, text, muted
  text, and border colours. Warning, danger, success, and profession colours
  keep their fixed meaning.

Both styles use the same information hierarchy, components, layout, and
behavior. Profession colors keep their game meaning in both styles. Do not add
a third component system for a new style.

## Source files

| File | Owner |
| --- | --- |
| [`src/shared/ui/tokens.css`](../../src/shared/ui/tokens.css) | Colors, materials, edges, corners, motion durations, and layers |
| [`src/shared/ui/components.css`](../../src/shared/ui/components.css) | Reusable panels, controls, fields, rows, slots, feedback, and resize controls |

The main renderer loads both files. Embedded Tools uses the same loaded styles.
The standalone Tools fixture imports the files because it has no parent
renderer.

Consumer stylesheets own layout. They must not define a second color, material,
corner, or layer system.

## Token hierarchy

Tokens have three layers and CSS variables are the only runtime source of
truth:

1. **Foundation** owns the 4px spacing ramp, fixed type roles, 34px ordinary
   controls, 30px dense-row controls, radii, motion, shadows, and z-index.
2. **Semantic** owns paired surface/foreground roles, text roles, borders,
   selection, hover, pressed, focus, commands, feedback, and profession data.
3. **Material** projects Classic or Modern paint, edge construction, radius,
   and shadow onto those semantic roles. Window chrome reserves space for the
   Classic artwork or Modern title bar. Material does not change outer window
   geometry, content ordering, typography preferences, or behavior.

The four typography roles are Display for identity, Interface for labels and
controls, Reading for prose and messages, and Data for codes, shortcuts,
timestamps, and counts. Guild Wars Original deliberately falls back to the
readable sans face for Reading. Data always uses the monospace stack.

Guild Wars Original and its packaged fallback are single-weight faces. The
system disables synthetic bold globally so Chromium cannot thicken and blur
their outlines. In Classic typography, hierarchy comes from the Display,
Interface, Reading, and Data roles, the fixed size ramp, brighter semantic
text, and spacing. `strong` and headings remain semantic in markup but stay at
the real 400 weight when Guild Wars Original is selected. Fonts with genuine
weight families use the same semantic weight tokens at 500, 600, and 700.

## Component rules

- Use `.ui-frame` for a framed panel. Hub and floating work windows attach
  [`frame.ts`](../../src/shared/ui/frame.ts) for the accepted Classic artwork.
  Vue windows use `useClassicFrame`. Both use the shared `--ui-art-*` chrome
  projection. The canvas is decorative and is removed on disposal. Its empty
  centre preserves one application of the saved panel material and opacity.
  Source regions and asset notices are in the
  [frame provenance](../../src/shared/ui/frame/README.md).
- Keep Travel, Characters, settings and build search/application inside Hub.
  Build Library in Home browses saved builds and the existing Guild Wars template
  folders. With Hub open, the Build shortcut enters this browser. Outside Hub, it opens
  the full authoring window.
  Trade and Whispers use independent floating windows with state across hide/show.
- Use `.ui-well` for a recessed content surface.
- Use `.ui-raised` for a pressable raised surface.
- Do not add a generic Card. Panes, sidebars, toolbars, and sections are
  transparent structural regions. Collections use flat rows. Repeated values
  use a ledger. Tiles are reserved for spatial commands such as Travel
  shortcuts and skill slots.
- Combine `.ui-panel-head` with `.ui-window-head` for floating windows that
  carry a title and supporting line. The shared primitive owns normal and
  constrained-viewport padding; feature styles must not retune it.
- Use `.ui-scroll` for scrollable wells and lists so scrollbar material stays
  consistent across Builds, Trade, and Travel.
- Use the shared components for buttons, fields, checks, tabs, rows, skill
  slots, progress, empty states, banners, toasts, and resize grips.
- Give each interactive control visible hover, focus, active, selected,
  and disabled states.
- Use the bright focus token. Focus must remain visible over game artwork.
- Vue feature code imports complex behavior through `src/ui`, never from Reka
  directly. Tabs and modal dialogs currently use these thin wrappers. Native
  buttons, fields, checks, ranges, and simple selects stay native.

### Map planner

Elite skills extends the shared frames, controls, skill slots, and skill details.
Classic, Modern, and Custom keep the same layout and interaction. Interface
type serves controls and Reading serves encounter notes. Capture data and
tracking behavior belong in
[`docs/elite-skills.md`](../../docs/elite-skills.md).

- Anchor the trigger and planner inside the world map's upper-right corner.
  Keep the planner compact (356px, capped by viewport width) and within the
  available map height. Search and filters precede flat skill rows; opening a
  skill replaces the list with details and capture locations.
- At short viewport heights (700px or less), scroll the whole planner so
  errors, search, results, and footer remain reachable. At taller heights,
  results and details scroll inside the panel. Hide pointer previews at
  narrow widths (650px or less).
- Keep each known position as an individual skill icon (28px). Do not combine
  nearby markers into numbers or add an intermediate group view.
  Distinguish the active boss with an accent outline and text label; a target
  outside the view uses a dashed edge marker and an explicit label.
- Hover or keyboard focus previews a skill; activation opens persistent
  details. Keep previews non-interactive. Search and selection are immediate.
- Keep **Back to skills** and **Close** in a sticky header, including short
  windows. Returning to skills preserves search and filters.
- Keyboard opening moves focus to search or the detail Back control. Back
  restores the result row when available, and closing returns focus to the
  map trigger or tracker control. Buttons use the shared bright two-pixel
  focus outline, separate from the active marker's accent outline.
- Place the compact mission tracker inside the mission map's upper-left
  corner. Keep its target, status, and manage action together. Empty map
  space remains outside the overlay's pointer hit area.

### Control states

- A default button is a routine command such as Export, Copy, Open, or Browse.
- A primary button is the single completion action for the current scope, such
  as Save changes, Apply team, Search, or the confirming action in a dialog.
- Selected and pressed are persistent states. They use `aria-selected` or
  `aria-pressed`; do not simulate them with the primary variant.
- Focus is keyboard position, not selection. It uses the focus ring only.
- Danger is reserved for destructive actions and always names the consequence.
- Classic gold is an inset selection marker or ornament, never the full
  perimeter of a routine command. Focus has a separate two-pixel perimeter and
  dark halo. It never reuses selection paint.
- Hover is temporary tone, pressed is temporary depth/displacement, navigation
  selection uses a leading rail or underline, and content selection includes a
  persistent text or icon marker. Selected + hover has its own stronger tone.
- Quiet controls are transparent at rest. They gain a surface only on hover or
  focus.

The saved interface style is `guild-wars`, `obsidian`, or `custom`. Font and
panel opacity remain independent. Panel opacity is from 65% through 100%.
These preferences must not change component markup, layout density, or
behavior. Every player-facing Settings and Tools stylesheet consumes the
shared tokens; local palette literals are not allowed.

## Window and interaction rules

- Windows share the resize interaction. Classic uses its corner artwork and an
  invisible hit area; Modern and Custom may show the shared grip.
- Pointer resize uses capture and handles cancellation and lost capture.
- Arrow keys resize the window. Shift increases the step.
- Start a Tools drag only from title-bar furniture.
- Do not start a drag from an interactive child.
- Keep a non-modal surface open when the player clicks Guild Wars behind it.
- Escape follows one rule on every GWonMac surface, before Guild Wars receives
  it: the surface that holds focus answers first, innermost level first (its
  menu, drawer, prompt or typed search), then an open disclosure closes, and
  only then the surface steps back or hides. From the game, Escape reaches the
  topmost surface, which still leaves an open inner level first. One step per
  physical press; an Escape during composition belongs to the input method.
- Every list and carousel moves one selection with the shared list keys:
  Up/Down and Control-P/N step, Page Up/Down move by the visible rows, Home/End
  jump, and no list wraps. Up at the top of a list stays; it never jumps to
  Back or the window chrome.
- A press that starts on a GWonMac surface owns its repeats and release. A held
  Enter activates a surface control once, and a key that closes a surface never
  continues into Guild Wars.
- Tab wraps inside the topmost open GWonMac surface's controls. It never
  leaves the game canvas (D-12): while Guild Wars has the keyboard, Tab and
  the keys after it stay in the game. A player enters a popout through its
  shortcut, a click, or `/` inside the panel.
- Keep native confirmation dialogs above non-modal Tools and Travel surfaces.
- Open Travel with Quick Travel destinations only; reveal the full catalogue as
  the player searches.
- Keep version availability collapsed in Settings unless something is
  unavailable.
- Keep a dragged window inside the viewport.
- Let Builds and teams and Trade Chat remain open together. Pointer interaction
  raises one explicit surface; do not add a generic tool registry.
- Treat Trade Chat as a working ledger, not a chat transcript or a variation of
  Builds and teams. Keep source, search, and intent controls above one semantic
  ledger, with the selected offer in a bottom inspector.
- At narrow widths, keep the Trade Chat list DOM and open the selected offer in
  an in-window sheet. The sheet keeps the shared button and scroll primitives.
- Merge Trade Chat messages immediately near the top. Away from the top, queue
  them silently without moving the reading position or showing a repeating
  arrival hint; merge the queue when the reader returns to the exact top.
- Reveal local Trade Chat results 25 at a time as the player nears the bottom,
  up to 200 results.
- Search offer text and the upstream `user:` character index together, then
  merge results by message timestamp. Clearing the field returns immediately
  to the live ledger.
- Keep every timestamp-distinct search result, including multiple posts from
  one character. Keep search results and the live ledger chronological.
- Open Trader prices inside the Trade Chat window and preserve the ledger DOM
  while it is hidden. Back returns to the previous ledger state and position.
- Use a master-detail price layout at wide widths and one navigable pane at
  narrow widths. Keep category, search, selected item, and chart range intact
  while moving between the list and detail.
- Distinguish observed buy and sell history with both labels and stable colors.
  Charts must expose exact values without depending on color or pointer hover.
- Keep saved offers and followed players in one right-anchored Saved drawer.
  It is non-modal at wide widths and an in-window sheet when narrow. Its entry
  and exit share the right edge, focus returns to its trigger, and reduced
  motion replaces translation with a brief cross-fade.
- Reveal compact save and follow actions on ledger-row hover or keyboard focus;
  keep them visible for touch input. Keep Whisper seller visible in the bottom inspector. Put save, follow, copy,
  and source commands under Actions. Escape and Command-Backspace close Actions,
  then the Saved drawer, then Trader prices, the narrow offer sheet or a
  player's listings, before Escape hides Trade; Command-Backspace does nothing
  at the listings. The message remains the visual focus.
- Scroll to revealed Trade Chat messages smoothly by default and instantly
  when reduced motion is active.
- Keep scrolling flex and grid children shrinkable.
- Use container width to change panel layout.
- Keep the skill bar usable with pointer, touch, and keyboard input.
- Do not show drag behavior on a read-only skill bar.
- Anchor a skill-key label to the slot's bottom-right corner. Add modifiers to
  the left without moving that corner or crossing into another slot.
- Keep exported text visible after copy succeeds or fails.
- Remove nonessential motion when reduced motion is active.

Tools chrome must receive input only inside its controls. Guild Wars must keep
normal keyboard and pointer input outside those controls.

## Verification

Open [`docs/ui-gallery.html`](../../docs/ui-gallery.html) to inspect the shipped
tokens and components. Run this command for the automated visual sweep:

```bash
node scripts/ui-visual-sweep.mjs
```

Check narrow, wide, short, transparent, and opaque states. Check the live
Settings dialog too. Body text must have a contrast ratio of at least 4.5:1.
Large text must have a ratio of at least 3:1. Test minimum opacity over bright,
detailed game artwork.

### Legibility model

[`appearance.ts`](../../src/renderer/appearance.ts) owns one worst-case model
for every text role. It measures the inks `tokens.css` paints, or the colours a
player chose, against the panel at its effective opacity over snow and over a
black scene, each with and without the accent hover layer, and against any
opaque surface the player recoloured. Reduce Transparency makes the effective
opacity 1; the saved opacity stays unchanged.

- Text, bright, muted, faint and the accent used as text move separately and
  only as far as they must. One opacity step never re-inks a whole role, and
  faint stays apart from muted wherever both read.
- At low opacity over snow the inks converge. Hierarchy then comes from type
  role and size: row detail, counts and hints use the smaller Reading role,
  keycaps the Data role, and headings the Display role.
- `--ui-accent-text` is the accent used as text: group headings, the scope
  chip, the build summary label, links, progress and the current-character
  marker. Only its lightness moves, so gold stays gold. Fills, rails, icons
  and the primary button keep the exact `--ui-accent`.
- The Classic head sits on painted metal that the model cannot measure, so its
  secondary copy (crumbs, caption, context) uses the text ink with the Classic
  text shadow.
- Reduce Transparency changes panel material only. A modal scrim keeps its
  value, so the game stays visible around the opaque panel.

## Compact reading surfaces

Whispers uses the shared `.ui-frame` with `data-variant="quiet"`: the theme's
edge remains, with no ornamental corner highlights. This opt-in variant also
supports future compact reading windows without changing existing Tools.
`.ui-reading-surface` uses the selected Reading font without text shadows;
the title keeps Interface typography. Quiet buttons keep secondary actions
subordinate to messages. `.ui-chat-bubble` owns incoming and outgoing material,
using shared text, well and selection tokens for Classic, Modern and Custom.

The messenger shows one conversation at a time. Back opens the people list;
sound, mute and cleanup live in the options menu. The author appears once in
the header and remains available to assistive technology on each message.
Incoming messages align left, replies right, and consecutive bubbles group
with tighter spacing. Keep settings and explanatory copy out of the transcript.

## Hub task presentation

Home shows current character and outpost context beside its breadcrumbs. Continue shows
up to three actionable recent destinations. Explicit searches retain unavailable
places with their reason. User pins keep their existing order and availability.
Tool rows show meaningful descriptions and resolved shortcut keycaps.

The top bar shows clickable ancestor breadcrumbs and an understated Back arrow.
Esc closes an open disclosure, then clears a typed query, then goes back one page,
then closes Hub; a page opened directly by its shortcut has no artificial Home step
for Esc.
Command-Backspace returns to the previous page from any focus in Hub, one page per
physical press; a page opened directly by its shortcut returns to Home, and Home
ignores it. The press bubbles to Hub, so a mounted view with its own inner level
(a confirmation, Character Switch settings, Travel Customize) steps out of it first,
the way Esc does, and marks the press handled. Travel and Characters, which keep
their own footer, list Command-Backspace there and name what Esc does now (clear,
back or close). Backspace only edits text and never navigates; typing or Backspace
on a button, the header or blank space edits the page's search: Hub search on list
stages, the view's own search in Travel and Characters. A form view has none, and
Travel's Customize panel keeps its keys like a form. History restores
query, selection, scroll and the focused control. The search field's description
leads with the page title, so a screen reader that stays in search after Back
hears where it landed. In a view, Up/Down step between controls in screen order
within the focused control's column (Settings sections or the section body), stop
at its ends and leave a scrolled region such as Build details to scroll natively.
Settings sections are a list: Right enters the first usable control and Left
returns to the section. Esc at a shortcut conflict answers it like Cancel. The
Characters search leads its Tab order, and the cards are one Tab stop on the
selected card. Form fields keep their draft for
the session by page path and field name, unless the stored value they started from
changed meanwhile. Hub lists keep focus in search and move the active descendant. First entry and restoration are separate: character cards,
account choices and action lists start on their useful item; search stays optional.
Fresh Home starts in search. Temporary app blur and popout handoffs retain the
session task; explicit closure starts a fresh task next time. Resume refreshes
current facts before execution. Account replacement invalidates prior targets.
Arrow keys connect results, search, navigation and actions. Character cards use
Left/Right; Up returns to search and stays there. Native text editing, range and
select controls retain their own keys. Actions only opens contextual actions. Known query scopes stay visible, and typing a command name offers one
relevant example. Neither examples nor typing execute an action.

Full team search previews show the difficulty and one line per assigned member.
Skill and attribute details remain available in Review. Template paths stay out
of these primary summaries. Preview content scrolls inside the current frame.
Review remains inside Hub and retains explicit target/apply guards. Every single
build selection opens Apply to me / Apply to hero, including exact-name searches.
The incoming build remains above the search field during target selection and
comparison. Current player and hero rows show observed equipped skills,
professions and invested attributes. Missing observations stay explicitly unknown;
a current bar is never filled from the incoming or saved build. Observer updates
preserve keyboard focus. Right Arrow opens supported child pages without applying.
Enter on an eligible current-party hero applies the displayed build to that hero.
Right opens optional comparison. Blocked heroes open their explanation instead
of executing. First entry focuses the first eligible current-party hero.
Back restores the search and incoming-build context.
Hero search lists observed unlocked heroes and current party members. Heroes
outside the party require adding first; single-build apply cannot change the roster.
Template browsing is read-only and shows populated folders from the existing
file reader. Apply rereads the selected template and refuses changed content.
Team authoring keeps the roster first; Team options expands difficulty and tags,
with the current difficulty visible in its summary.

Floating Trade keeps connection state beside result counts. Common filters share
a row when width permits. Secondary actions expand inside the inspector without
replacing the ledger. Opening a seller's Whisper leaves the Trade query and
selected offer intact. Floating windows share visual and keyboard stacking.
Escape closes an expanded Actions menu before its window. In the Whispers
picker, Escape clears typed text before it hides the window, and Up/Down walk
the listed conversations, friends and recent people while focus stays in the
search. Command-Backspace returns from a conversation to the picker, except in
the message field, where it keeps its macOS meaning.

Only Hub starts locked. Its subtle top-bar lock enables dragging by
the header and resizing through a 36px corner hit area. Floating tools have no
lock control and remain directly movable and resizable. Classic uses its corner
artwork without painting a second resize button. Close is a plain X with a usable
hit target and visible keyboard focus. Hub retains its adjusted geometry across
pages; windows remain bounded by the viewport. Alt+arrows on Hub's unlocked lock
control move it; arrows on its resize handle resize it. Reset Hub position is
available in Hub preferences and Settings → Appearance. It restores default
position and size, and locks the Hub. Placement uses the shared validated window
placement format in account-profile browser storage; a new renderer always starts
locked. Reset removes only the Hub placement key.

Whispers paints its background once across the complete frame interior. Its
title is vertically centered, and conversation controls sit above the picker
or transcript. There is no docking control or embedded Hub chat layout.

Maps pairs each native switch with its opacity control. Disabled layers retain
but disable opacity controls. External settings updates repaint the same view;
failed writes restore saved state and show a recoverable inline error.

### Compact build metadata

Hub build results keep the skill bar and invested attribute ranks in each row.
There is no separate lower preview for individual builds and no visible template
file path. Profession codes remain beside the title, such as Protection
Mo/Me, in smaller muted text. Native templates also show a folder icon and
muted relative folder path. Incoming and equipped comparisons use the same
compact presentation.
Attributes are grouped under one Tango icon per profession, with abbreviated
labels and ranks separated by fine dividers; tooltips and
accessible names retain the full attribute name. Labels distinguish Illusion
Magic (IM) from Inspiration Magic (InM). Narrow windows wrap attributes below
the eight skills. Profession artwork has one shared Tango asset set for Hub,
Character Switch, Builds, Elite Skills and Trader views.

### Build folder search

The `build` command searches native template folders as well as saved builds.
Plain words are combined with AND across build names, tags and folder names,
regardless of word order. An unquoted full profession name or code filters the
primary profession. An exact pair such as `Mo/Me` matches both professions.
Quoted terms keep names with spaces together and allow literal profession words.

- `build farming monk`: Monk builds with Farming in their folder, name or tags.
- `build teams/farming monk`: Monk templates under consecutive Teams/Farming folders.
- `build teams farming monk`: the same words, without requiring path order.
- `build "Team Builds/Farming" monk`: a path containing a folder name with spaces.
- `build folder:"Team Builds" monk`: explicitly require that folder, including descendants.
- `build folder:Monk mesmer`: Mesmer templates stored in the Monk folder.
- `build folder:/ monk`: Monk templates directly in the Skills root.

Search is case-insensitive and supports word prefixes. Slash paths require exact
parent segments and allow a prefix in the last segment. A trailing slash makes
that last segment exact; a leading slash anchors the path at the Skills root.
Backslashes are accepted as path separators. Quotes may remain unfinished while
typing. Unknown folders return no results. Imported build provenance is not a
current template folder. File identities and the reread-before-apply guard stay
unchanged; folder searches never apply a build automatically.

Typing a printable character or Backspace while a Hub result has keyboard focus
resumes the search at its saved caret or selection. This also applies on target-selection
pages. Arrows still navigate results; Enter activates the selected result;
Command-Backspace from a result goes back in Hub history.

### Build continuity and completion

Build browsing uses the same matcher in global search and nested folders. Browse
immediate child folders, including parents whose templates are all in descendants.
`Mo/Me` requires that exact profession pair; `folder:Mo/Me` searches that folder.
Reading, empty, failed, and unreadable template states are distinct. Retry uses the
existing reader and keeps previously valid builds visible.

Incoming/current comparisons mark changed slots and invested-rank deltas. Details
exposes skill descriptions and full attribute names without adding tab stops to
every skill. Already equipped requires complete, equal observations. A saved
build's Details can open its canonical record in the authoring workspace.

Apply shows progress and explicit partial failures through the existing runner.
Confirmed completion closes Hub with a brief receipt naming the build and target.
The receipt stands where the Hub's footer was, not as a window toast, and ends
when Hub opens again. An outcome that arrives while Hub is open, such as the
invite after Travel and invite, goes to the status line instead.
The library controller retains up to three recent build/hero references for this
renderer session; Continue reopens the named target for review. Native files and
live targets are revalidated before applying again. Saved build usage updates the
existing timestamp without adding an Undo entry; no new persistent library schema
or durable hero-agent references are introduced.
